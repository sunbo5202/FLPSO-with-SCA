function individual_index=SAEpsSort(fitness,violation,eps)
N=length(violation);
individual_index=1:N;
pop1_index=individual_index(violation<=eps);
pop2_index=individual_index(violation>eps);
[~,temp1]=sort(fitness(pop1_index));
[~,temp2]=sort(violation(pop2_index));
individual_index=[pop1_index(temp1),pop2_index(temp2)];
individual_index=individual_index';
end