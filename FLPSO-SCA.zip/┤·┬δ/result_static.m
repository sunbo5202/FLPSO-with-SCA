function result=result_static(CPPSO_Simple10F)
runs=CPPSO_Simple10F;
for i=1:28
    result(i,1)=min(runs(i,:));
    result(i,2)=max(runs(i,:));
    result(i,3)=median(runs(i,:));
    result(i,4)=mean(runs(i,:));
    result(i,5)=std(runs(i,:));
end